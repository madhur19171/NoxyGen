const char *gitversion = "d9be54497618168d7bab49648344df98f42a7f52";
